import os
import platform
import time
def load_bar():
    while True:
        print("⬛⬜⬜⬜⬜⬜⬜")
        time.sleep(0.05)
        os.system('cls')
        print("⬛⬛⬜⬜⬜⬜⬜")
        time.sleep(0.05)
        os.system('cls')
        print("⬛⬛⬛⬜⬜⬜⬜")
        time.sleep(0.05)
        os.system('cls')
        print("⬛⬛⬛⬛⬜⬜⬜")
        time.sleep(0.05)
        os.system('cls')
        print("⬛⬛⬛⬛⬛⬜⬜")
        time.sleep(0.05)
        os.system('cls')
        print("⬛⬛⬛⬛⬛⬛⬜")
        time.sleep(0.05)
        os.system('cls')
        print("⬛⬛⬛⬛⬛⬛⬛")
        time.sleep(0.05)
        os.system('cls')
        break